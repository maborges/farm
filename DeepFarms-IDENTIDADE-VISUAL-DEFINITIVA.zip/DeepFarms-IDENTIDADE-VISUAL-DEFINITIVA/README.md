# DeepFarms — Identidade Visual Definitiva
Master aprovado: `deepfarms-mark-master.svg`
Cor institucional: `#006B3D`. Sem gradientes.

Todos os derivados de marca deste pacote usam a mesma geometria do master aprovado.
O hero é a imagem previamente aprovada.

Regra para Codex: não redesenhar, reinterpretar, vetorizar novamente ou simplificar a marca.
